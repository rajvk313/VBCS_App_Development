define([], () => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.getCustomersToNominate = function(customersData, nominatedCustomers){
    var customersToNominate = [];
    var find = false;
    for(var i=0;i<customersData.length;i++){
      if(customersData[i].EmailAddress!=null){
        find = false;
        for(var j=0;j<nominatedCustomers.length;j++){
          if(customersData[i].EmailAddress==nominatedCustomers[j].emailAddress){
            find = true;
            break;
          }
        }
      if(!find){
        customersToNominate.push(customersData[i]);
      }
      }
    }
    return customersToNominate;
  }
  return PageModule;
});
