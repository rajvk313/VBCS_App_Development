define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadData extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions, $chain } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'crmRestApi/getall_accounts',
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Nomination',
      });

      const customersToNominate = await $functions.getCustomersToNominate(response.body.items, response2.body.items);

      $variables.AccountsADP.data = customersToNominate;
    }
  }

  return loadData;
});
