define([], () => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.settingLocale = function(currentLocale){
    if(currentLocale){
      window.localStorage.setItem('current.locale',currentLocale);
    }
  };
  return PageModule;
});
