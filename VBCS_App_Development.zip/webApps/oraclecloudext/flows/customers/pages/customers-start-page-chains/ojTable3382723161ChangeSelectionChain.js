define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable3382723161ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.accountsId
     */
    async run(context, { accountsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_338272316_1SelectedId = accountsId;
    }
  }

  return ojTable3382723161ChangeSelectionChain;
});
