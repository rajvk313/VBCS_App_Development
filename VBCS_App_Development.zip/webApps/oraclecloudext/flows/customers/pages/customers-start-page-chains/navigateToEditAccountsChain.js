define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditAccountsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.accountsId
     */
    async run(context, { accountsId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageCustomersEditAccountsResult = await Actions.navigateToPage(context, {
        page: 'customers-edit-accounts',
        params: {
          accountsId: accountsId,
        },
      });
    }
  }

  return navigateToEditAccountsChain;
});
