define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadAccountsChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'crmRestApi/get_accounts',
        responseType: 'getAccountsResponse',
        uriParams: {
          'accounts_Id': $page.variables.accountsId,
        },
      }, { id: 'loadAccounts' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedAccounts = callRestResult.body;
      $page.variables.accounts = $page.variables.fetchedAccounts;
      $page.variables.accountsETag = callRestResult.headers.get('ETag');
    }
  }

  return loadAccountsChain;
});
