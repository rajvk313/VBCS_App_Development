define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class MenuMenuActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $fragment, $application, $constants, $variables } = context;

      if ($application.variables.avatarItems[0].id) {

        await Actions.logout(context, {
          logoutUrl: 'https://idcs-88f2657e740642e9b2d53884e9a0304e.identity.oraclecloud.com/ui/v1/login',
        });
      }
    }
  }

  return MenuMenuActionChain;
});
