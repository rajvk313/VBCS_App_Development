define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($page.functions.validateForm("new-employee")) {
        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_Employee',
          body: $variables.newEmpployee,
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Employee created successfully',
          displayMode: 'transient',
          type: 'confirmation',
        });
      }
    }
  }

  return ButtonActionChain;
});
