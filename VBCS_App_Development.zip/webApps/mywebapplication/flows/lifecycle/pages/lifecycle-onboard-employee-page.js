define([], () => {
  'use strict';

  class PageModule {
    validateForm(form){
      var myform = document.getElementById(form);
      if(myform.valid === "valid"){
        return true;
      }
      else {
        myform.showMessages();
        myform.focusOn("@firstInvalidShown");
        return false;
      }
    }
  }
  
  return PageModule;
});
