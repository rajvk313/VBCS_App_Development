define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.operation 
     */
    async run(context, { operation = 'add' }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const calculate = await $functions.calculate($variables.number1, $variables.number2, operation);

      $variables.result = calculate;
    }
  }

  return ButtonActionChain2;
});
