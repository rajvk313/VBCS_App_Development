define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteEmployeeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeId 
     */
    async run(context, { employeeId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const getAll_ExpenseResponse = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Expense',
        uriParams: {
          q: "employeeId="+employeeId,
        },
      });

      if (getAll_ExpenseResponse.body.count !== 0) {

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_Expense',
          uriParams: {
            'Expense_Id': getAll_ExpenseResponse.body.items[0].id,
          },
        });
      }

      const getAll_AddressResponse = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Address',
        uriParams: {
          q: "employeeId="+employeeId,
        },
      });

      if (getAll_AddressResponse.body.count !== 0) {
        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_Address',
          uriParams: {
            'Address_Id': getAll_AddressResponse.body.items[0].id,
          },
        });
      }

      const getAll_InventoryResponse = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Inventory',
        uriParams: {
          q: "employeeId="+employeeId,
        },
      });

      if (getAll_InventoryResponse.body.count !== 0) {
        const response3 = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_Inventory',
          uriParams: {
            'Inventory_Id': getAll_InventoryResponse.body.items[0].id,
          },
        });
      }

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_Employee',
        uriParams: {
          'Employee_Id': employeeId,
        },
      }, { id: 'deleteEmployee' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Delete failed',
          message: `Could not delete data: status ${callRestResult.status}`,
          displayMode: 'persist',
          type: 'error',
        }, { id: 'fireErrorNotification' });

        return;
      }

      // Resets selection variable
      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.oj_table_2002782212_1SelectedId',
        ],
      }, { id: 'resetSelection' });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.employeeListSDP,
        refresh: null,
      }, { id: 'refreshDataProvider' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Employee deleted',
        message: `Employee [${employeeId}] successfully deleted`,
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'fireSuccessNotification' });
    }
  }

  return deleteEmployeeChain;
});
