define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'JSONPlaceHolder/getUsersUserid2',
        uriParams: {
          userid: rowKey,
        },
      }, { id: 'callRestEndpointUserInformation' });

      $flow.variables.userInformation = response.body;

      const toMainUserInformation = await Actions.navigateToPage(context, {
        page: 'main-user-information',
        params: {
          userId: $application.user.username,
        },
      });
    }
  }

  return TableFirstSelectedRowChangeChain;
});
