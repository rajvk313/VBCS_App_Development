define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.emailAddressCriteria.value',
    '$page.variables.firstNameCriteria.value',
    '$page.variables.lastNameCriteria.value',
    '$page.variables.qualificationCriteria.value',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.employeeListSDP.filterCriterion',
  ],
      });
    }
  }

  return ButtonActionChain;
});
