define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $and, $co, $eq } = context;

      $variables.firstNameCriteria.value = $variables.firstNameCriteria.value ? $variables.firstNameCriteria.value : '';
      $variables.lastNameCriteria.value = $variables.lastNameCriteria.value ? $variables.lastNameCriteria.value : '';
      $variables.emailAddressCriteria.value = $variables.emailAddressCriteria.value ? $variables.emailAddressCriteria.value : '';
      $variables.qualificationCriteria.value = $variables.qualificationCriteria.value ? $variables.qualificationCriteria.value : '';

      $variables.employeeListSDP.filterCriterion = {
  op: '$and',
  criteria: [
    {
      op: '$co',
      attribute: 'firstName',
      value: $variables.firstNameCriteria.value,
    },
    {
      op: '$co',
      attribute: 'lastName',
      value: $variables.lastNameCriteria.value,
    },
    {
      op: '$eq',
      attribute: 'emailAddress',
      value: $variables.emailAddressCriteria.value,
    },
    {
      op: '$eq',
      attribute: 'qualification',
      value: $variables.qualificationCriteria.value,
    },
  ],
};
    }
  }

  return ButtonActionChain1;
});
