define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Expense',
        uriParams: {
          q: "employeeId =" + $page.variables.deletingEmployeeId,
        },
      });

      if (response2.body.count !== 0) {
        const response3 = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_Expense',
          uriParams: {
            'Expense_Id': response2.body.items[0].id,
          },
        });
      }

      const response4 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Address',
        uriParams: {
          q: "employeeId = "+$page.variables.deletingEmployeeId,
        },
      });

      if (response4.body.count !== 0) {
        const response5 = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_Address',
          uriParams: {
            'Address_Id': response4.body.items[0].id,
          },
        });
      }

      const response6 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Inventory',
        uriParams: {
          q: "employeeId =" +$page.variables.deletingEmployeeId,
        },
      });

      if (response6.body.count !== 0) {
        const response7 = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_Inventory',
          uriParams: {
            'Inventory_Id': response6.body.items[0].id,
          },
        });
      }

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/delete_Employee',
        uriParams: {
          'Employee_Id': $variables.deletingEmployeeId,
        },
      });

      await Actions.callChain(context, {
        chain: 'loadEmployeeData',
      });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.EmployeeADP,
        refresh: null,
      });

      const deleteUserDialogClose = await Actions.callComponentMethod(context, {
        selector: '#delete-user-dialog',
        method: 'close',
      });
    }
  }

  return ButtonActionChain2;
});
